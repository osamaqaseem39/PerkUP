import React from 'react';
import LiveSearch from './LiveSearch';

function App() {
  return (
    <div className="App">
      <LiveSearch />
    </div>
  );
}

export default App;

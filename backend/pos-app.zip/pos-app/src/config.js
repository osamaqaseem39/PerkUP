const config = {
    consumerKey: 'ck_cb86513d712248d10d15cb9fc4799c45ee913cb1',
    consumerSecret: 'cs_44cb06ca24c0f63b976dd482fff1943b890b8704',
    baseUrl: 'https://testing-tz7a.wp1.site/wp-json/wc/v3',
  };
  
  export default config;
  